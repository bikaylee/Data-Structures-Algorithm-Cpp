//Created by Frank M. Carrano and Timothy M. Henry.
//Copyright (c) 2017 Pearson Education, Hoboken, New Jersey.

/*
 Link-list driver program to test methods in the link-list.cpp.
 
@Modified by: Bixia Deng
@version: 12/ 04 / 18
@assignment: Lab 3
@Editor: Xcode
@instructor: Samuel Johnson

*/

#include <iostream>
#include <string>
#include "LinkedList.h" // ADT list operations
using namespace std;


void displayList(ListInterface<int>* listPtr)
{
    //cout << "The list contains " << endl;
    for (int pos = 1; pos <= listPtr->getLength(); pos++)
    {
        try
        {
            cout << listPtr->getEntry(pos) << " ";
        }
        catch(PrecondViolatedExcep except)
        {
            cout << "Exception thrown getting entry inserted at position " << pos << endl;
            cout << except.what() << std::endl;
        }
    }
}

int main()
{
    ListInterface<int>* listPtr = new LinkedList<int>();
    string str;

    string input = "y";
    while(input == "y")
    {
        cout << "Enter a list of integers: ";
        getline(cin, str);
        
        int itemCount = 0;
        
        for(int i = 0, del = 0, start = 0; i < str.length(); i++) {
            if(str.substr(i, 1) == " " || i == str.length()-1)
            {
                del = i + 1;
                int num = stoi(str.substr(start, del-start));
                start = del;
                listPtr->insert(itemCount+1, num);
                itemCount++;
            }
        }
        
        int target, replaceVal;
        cout << "Enter a value to be modified: ";
        cin >> target;
        cout << "Enter replacement value: ";
        cin >> replaceVal;
        
        int occurrence = listPtr->replaceItem(target, replaceVal);
        
        cout << "Modified list: ";
        displayList(listPtr);
        cout << "\nNumber of items replaced: " << occurrence << endl;
        
        listPtr->clear();
        displayList(listPtr);
        str = "";

        cout << "Would you like to modify another list (y/n)? ";
        cin >> input;
        
        cout << endl;
        
        cin.clear();
        cin.ignore();
    }
    
}
